import logo from './logo.svg';
import './App.css';
import Header from'./components/Header';
import Content from'./components/Content';
import Body from './components/Body';

function App() {
  return (
    <div className="App">
     <Header/>
     
     <Body/>
    </div>
  );
}

export default App;
