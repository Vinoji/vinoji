import React, { useState } from 'react';
import "./components/contents/M.scss"
import { BiChevronRight } from "react-icons/bi";
const MenuItem = ({ label, subMenuItems }) => {
  const [showSubMenu, setShowSubMenu] = useState(false);

  const handleMouseEnter = () => {
    setShowSubMenu(true);
  };

  const handleMouseLeave = () => {
    setShowSubMenu(false);
  };

  return (
    <li onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
      {label}  {label !== "Categories" && <BiChevronRight style={{position:'absolute',left:'170px',marginTop:'13px'}}/> }
      {subMenuItems && showSubMenu && (
        <ul className="sub-menu">
          {subMenuItems.map((subMenuItem) => (
            <MenuItem key={subMenuItem.label} {...subMenuItem} />
          )) }
           
        </ul>
        
      )}
    </li>
  );
};

const Menu = ({ menuItems }) => {
  return (
    <ul className="new">
      {menuItems.map((menuItem) => (
        <MenuItem key={menuItem.label} {...menuItem} />
      ))}
    </ul>
    
  );
};

const App = () => {
  const menuItems = [ {label: 'Categories', subMenuItems: [   {          label: 'Development', subMenuItems: [            { label: 'Web Development' ,subMenuItems: [            { label: 'Web Development' },]}, { label: 'Datascience' },   { label: 'Web Development' }, { label: 'Datascience' }, { label: 'Web Development' }, { label: 'Datascience' }, { label: 'Web Development' }, { label: 'Datascience' }, { label: 'Web Development' },         ],
        },
        {          label: 'Business', subMenuItems: [            { label: 'Communication' }, { label: 'Sales' },          ],
        },
        {          label: 'Finance ', subMenuItems: [            { label: 'Finance' }, { label: 'Economics' },          ],
      },
      {          label: 'IT and Software', subMenuItems: [            { label: 'Communication' }, { label: 'Sales' },          ],
    },
    {          label: 'Design', subMenuItems: [            { label: 'Communication' }, { label: 'Sales' },          ],
  },
  {          label: 'Marketing', subMenuItems: [            { label: 'Communication' }, { label: 'Sales' },          ],
},
{          label: 'Life Style', subMenuItems: [            { label: 'Communication' }, { label: 'Sales' },          ],
},
{          label: 'Music', subMenuItems: [            { label: 'Communication' }, { label: 'Sales' },          ],
},
{          label: 'Health', subMenuItems: [            { label: 'Communication' }, { label: 'Sales' },          ],
},
      ],
    },
  
  ];

  return (
    <div style={{width:'100%'}}>
    
      <Menu menuItems={menuItems} />
    </div>
  );
};

export default App;
