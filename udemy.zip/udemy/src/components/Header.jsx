import React from "react";
import logo from './/assets/logo-udemy.svg';
import Button from 'react-bootstrap/Button';
import { MdOutlineShoppingCart } from "react-icons/md";
import { GiHamburgerMenu } from "react-icons/gi";
import { HiGlobeAlt } from "react-icons/hi";
import'./Style.scss';
import { ImSearch } from "react-icons/im";
import Menu from '../Menu'
import { useState } from "react";
import Offcanvas from 'react-bootstrap/Offcanvas';
import HoverPopup from './Pcard';
import Dropdown from './DropDown'
import { BsGlobe2 } from "react-icons/bs";
function Header() {

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  
  return (
    <div>
    <div className="headerPrimary">
       
          <div className="left part">
            <div className="menu"><GiHamburgerMenu onClick={handleShow}size={20}/></div>
            <div className="udemyLogo" id='logo1'>
              <img src={logo} className="logo" alt="logo"></img>
            </div> <div className="categoriesDiv">
             
               <div className="mi ">

      <Menu/>
      </div> 
            </div> 
          </div>
         
         
          <div className="mid part" id="mop">
            <div className="searchIcon">
              <ImSearch className="icon" size={17} />
            </div>
            <input className="searchBar" placeholder="Search for anything"></input>
          </div>
          <div className="right part">
          <HoverPopup popupContent=<span>Get your team access to over 19,000 top Udemy courses, anytime, anywhere.
<div> <Button id='q1'className="signup button">Sign up</Button></div></span>>    <div className="businessDiv ">
              <span className="business " style={{whiteSpace:'nowrap'}}>Udemy Business</span>
            </div></HoverPopup>
        <HoverPopup popupContent=<span>Get your team access to over 19,000 top Udemy courses, anytime, anywhere.
        <div> <Button id='q1'className="signup button">Sign up</Button></div></span>>     <div className="teachDiv">
              <span id="t" className="teach"style={{whiteSpace:'nowrap'}}>Teach on Udemy</span>
            </div></HoverPopup>
            <div className="searchIcon1">
              <ImSearch className="icon1" size={17} />
            </div>
            <div className="cartDiv">
              <MdOutlineShoppingCart className="icon"  style={{color:'black'}}size={25}/>
            </div>
            <Button id='q1'className="login button">Log in</Button>
            <Button id='q1'className="signup button">Sign up</Button>
            <div><Button id='q1' style={{backgroundColor:'white',color:'black',borderColor:'black',borderRadius:'0px',width:'40px',height:'40px',marginBottom:"3px"}}><HiGlobeAlt size={24}style={{margin:'0px -4px'}}/></Button></div>
          </div>
          <Offcanvas show={show} onHide={handleClose} className='offcan' id='off'style={{width:'52%',}}>
          <div style={{padding:'20px 20px 0px',color:'#5727D3'}} >
          <div>Log in</div>
           <div>SignUp</div>
           
          </div>
          <hr></hr>
          <Offcanvas.Body>
            <span style={{fontSize:'14px',fontWeight:800 ,color:'#6A6F73'}}>Most Popular</span>
            <Dropdown/>
            <hr></hr>
           
            <span style={{fontSize:'14px',fontWeight:800 ,color:'#6A6F73'}}>More from Udemy</span>
           <div style={{}}>
           <div>Udemy Business</div>
           <div>Get the App</div>
           <div>Invite friends</div>
           <div>Help</div></div>
           <Button variant="outline-dark"> <BsGlobe2/>  English</Button>
          
          </Offcanvas.Body>
         
        </Offcanvas>
        
        </div></div>
      );
    }
    



export default Header;
