import React from "react";
import'./vidio.scss';
import {AiOutlineStar} from 'react-icons/ai'
// import StarBorderIcon from "@material-ui/icons/StarBorder";
import {FaStarHalfAlt} from 'react-icons/fa'

function VideoCard(props) {
  return (
    <div className="videoCard">
      <img className="courseImg" src={props.imgSrc} alt="courseImg"></img>
      <h3 className="titl">{props.courseTitle}</h3>
      <p>{props.instructor}</p>
      <div className="ratingDiv">
        <span className="rating">{props.rating}</span>
        <span className="stars">
          <AiOutlineStar />
          <AiOutlineStar />
          <AiOutlineStar />
          <AiOutlineStar />
          <FaStarHalfAlt />
        </span>
        <span className="noOfStudents">{props.noOfStudents}</span>
      </div>
      <h3 className="price titl">{props.price}</h3>
      <div className="bestsellerBadge">Bestseller</div>
    </div>
  );
}

export default VideoCard;