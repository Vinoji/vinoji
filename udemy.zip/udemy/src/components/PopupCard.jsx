import React from 'react'
import Card from 'react-bootstrap/Card';
import logo from './/assets/u1.jpg';
// import './pcard.scss'
const PopupCard = () => {
  return (
    <div class="container">
    <div class="row p-lg-5">
     <div class="col-lg-6 text-center text-lg-start mt-lg-3 mt-xl-0">
     <img
        src='https://www.udemy.com/staticx/udemy/images/v7/logo-ub.svg'
        width={192}
        height={33}
        
        
      ></img> 
   </div>
     <div class="col-lg-6">
       <p class="text-center text-lg-start mt-2 mt-lg-0"> <img
        src='  https://s.udemycdn.com/home/non-student-cta/UB_Promo_1200x1200.jpg'
        width={400}
        height={400}
        alt="instructorImg"
        className="instructorImg"
        
      ></img></p>
       <h2 class="fw-bold mt-2 text-center text-lg-start">Upskill your team with Udemy Business</h2>
       <ul>
         <li class="fs-6 mt-2">Unlimited access to 19,000+ top Udemy courses, anytime, anywhere you will learn courses</li>
         <li class="fs-6 mt-2">International course collection in 14 languages you will learn easily</li>
         <li class="fs-6 mt-2">Top certifications in tech and business to get your first job</li>
      </ul>          
      <div class="d-grid d-lg-block">
       <button type="button" class="btn btn-dark mt-2 me-2">Get Udemy Business</button>
       <button type="button" class="btn btn-outline-dark mt-2 me-2">Learn More</button>
      </div>
     </div>
     
    </div>
    <div className="row p-lg-5">
      <div className="col-lg-6 text-center text-lg-start mt-3 mt-lg-0">
      <img
        src={logo}
        width={400}
        height={400}
        alt="instructorImg"
        // className="instructorImg"
      ></img>
      </div>
      <div className="col-lg-6 my-5">
         <h3 className="fw-bold text-center text-lg-start mt-lg-5" style={{fontFamily:'SuisseWorks,Georgia,Times,times new roman,serif,apple color emoji,segoe ui emoji,segoe ui symbol',fontWeight:700}}>Become an instructor</h3>
         <p className="fs-6 text-center text-lg-start" style={{fontFamily:' udemy sans,sf pro text,-apple-system,BlinkMacSystemFont,Roboto,segoe ui,Helvetica,Arial,sans-serif,apple color emoji,segoe ui emoji,segoe ui symbol',fontSize:'30px',fontWeight:400,lineHeight:1.4,marginBottom:'15px'}}>Instructors from around the world teach millions of students on Udemy. We provide the tools and skills to teach what you love.
</p>
         <div className="d-grid d-lg-block">
           <button type="button" className="btn btn-dark btn-block">Start teaching today</button>
         </div>
           
      </div>
    </div>
  </div> 
  )
}

export default PopupCard