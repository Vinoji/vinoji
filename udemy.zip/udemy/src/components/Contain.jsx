import React from "react";
import'./Style.scss';
function App(props) {
  return (
    <div className="contain">
{props.children}
    
    </div>
  );
}

export default App;
