import React from "react";
import "./Business.css";
import logo from './/assets/h5.jpg';
import { GoPrimitiveDot } from "react-icons/go";
import Button from 'react-bootstrap/Button';
import { Row } from "react-bootstrap";
function Business() {
  return (
    <div className="busine">
      
     
      <div>
      <img
        src='https://www.udemy.com/staticx/udemy/images/v7/logo-ub.svg'
        width={192}
        height={33}
        
        
      ></img> 
      <h3 className="upskill">Upskill your team with<br></br> Udemy Business</h3>
      <div className="list">
        
        <div className="li"><GoPrimitiveDot/> Unlimited access to 19,000+ top Udemy <br style={{marginLeft:'20px'}}></br>courses, anytime, anywhere</div>
        <div className="li"><GoPrimitiveDot/>International course collection in 14 languages</div>
        <div className="li"><GoPrimitiveDot/>Top certifications in tech and business</div>
        {/* <span><Button variant="dark" style={{borderRadius:'0px',fontWeight:700,padding:'10px'}}>GetUdemyBusiness</Button></span><span>  <Button  style={{borderRadius:'0px',fontWeight:700,padding:'10px'}}variant="outline-dark">LearnMore</Button></span> */}
         <div className="d-grid d-lg-block">
              <button type="button"  style={{borderRadius:'0px'}}className="btn btn-dark mt-2 me-2">Get Udemy Business</button>
              <button type="button" style={{borderRadius:'0px'}}className="btn btn-outline-dark mt-2 me-2">Learn More</button>
             </div>
        
    </div>
      </div>

      <div>
      <img
        src='  https://s.udemycdn.com/home/non-student-cta/UB_Promo_1200x1200.jpg'
        width={400}
        height={400}
        alt="instructorImg"
        className="instructorImg"
        
      ></img>
    
      </div>
      
      
    </div>
  );
}

export default Business;