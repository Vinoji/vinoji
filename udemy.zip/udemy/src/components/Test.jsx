import Dropdown from "react-multilevel-dropdown";
import React from "react";
import './test.scss'
import { useState } from "react";


export default function App() {

    const [show, setShow] = useState(false);
    const showDropdown = (e)=>{
        setShow(true);
    }
    const hideDropdown = e => {
        setShow(false);
    }
  return (
    <Dropdown title="Categories" position="right" 
    onMouseEnter={showDropdown} 
    onMouseLeave={hideDropdown}
     renderMenuOnMount={true}>
    {show&&  <div   onMouseEnter={showDropdown}onMouseLeave={hideDropdown}><Dropdown.Item >Item 1</Dropdown.Item>
      <Dropdown.Item>
        Item 2
        <Dropdown.Submenu position="right">
          <Dropdown.Item>Subitem 1</Dropdown.Item>
          <Dropdown.Item>Subitem 2</Dropdown.Item>
        </Dropdown.Submenu>
      </Dropdown.Item>
      <Dropdown.Item>Item 3</Dropdown.Item></div>}
    </Dropdown>
  );
}
