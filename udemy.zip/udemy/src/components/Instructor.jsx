// import React from "react";
// import "./Instructor.scss";
// import logo from './/assets/u1.jpg';
// import Button from 'react-bootstrap/Button';
// function BecomeInstructor() {
//   return (
//     <div className="becomeInstructorDiv">
//       <div className="backgroundColorDiv"></div>
//       <img
//         src={logo}
//         width={400}
//         height={400}
//         alt="instructorImg"
//         className="instructorImg"
//       ></img>
//       <div className="contentDiv">
//         <h2 className="heading">Become an instructor</h2>
//         <p className="about">
//           Top instructors from around the world teach millions of students on
//           Udemy. We provide the tools and skills to teach what you love.{" "}
//         </p>
//         <div><Button variant="dark" style={{borderRadius:'0px',fontWeight:600,padding:'10px'}}>Start teaching today</Button></div>
//       </div>
//     </div>
//   );
// }

// export default BecomeInstructor;


import Button from 'react-bootstrap/Button';
import React from "react";
import "./Instructor.scss";

function InstructorBanner() {
  return (
    <div className="instructorBanner">
      <img
        src="https://s.udemycdn.com/home/non-student-cta/instructor-1x-v3.jpg"
        alt="banner"
        className="instructorBanner__image"
      />
      <div className="instructorBanner__text">
        <h3 className='upskill'>Become an instructor</h3>
        <p className='li'>
          Instructors from around the world teach <br /> millions of students on
          Udemy. We provide <br /> the tools and skills to teach what you love.
        </p>
        {/* <a href="https://www.udemy.com/teaching/?ref=teach_home-body">
          Start teaching today
        </a> */}
         <div><Button variant="dark" style={{borderRadius:'0px',fontWeight:600,padding:'10px'}}>Start teaching today</Button></div>
      </div>
    </div>
  );
}

export default InstructorBanner;