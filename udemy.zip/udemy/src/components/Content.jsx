import React from "react";

import'./Style.scss';
import Contain from './Contain'
import { useState } from "react";
import Carousel from 'better-react-carousel'
function Content() {

  
const [ishovering,setishovering]=useState(true);
const [ishovering1,setishovering1]=useState(false);
const [ishovering2,setishovering2]=useState(false);
const [ishovering3,setishovering3]=useState(false);
const [ishovering4,setishovering4]=useState(false);
const [ishovering5,setishovering5]=useState(false);
const [ishovering6,setishovering6]=useState(false);
function handlemouseover(){
setishovering(true)
}

function handlemouseout(){
    setishovering(false)
    }
function handlemouseover1(){
    setishovering1(true)
}
function handlemouseout1(){
    setishovering1(false)
    
}
function handlemouseover2(){
    setishovering2(true)
}
function handlemouseout2(){
    setishovering2(false)
}
function handlemouseover3(){
  setishovering3(true)
}
function handlemouseout3(){
  setishovering3(false)
}

function handlemouseover4(){
  setishovering4(true)
}
function handlemouseout4(){
  setishovering4(false)
}
function handlemouseover5(){
  setishovering5(true)
}
function handlemouseout5(){
  setishovering5(false)
}
function handlemouseover6(){
  setishovering6(true)
}
function handlemouseout6(){
  setishovering6(false)
}



  return (
    <div className='frame1'>
       
     <img width="100%" height="400" alt="" src="https://img-c.udemycdn.com/notices/home_banner/image_udlite/15a7432a-4bd9-4aef-b68a-a07482b98f06.jpg"></img>
     <div className='banner1'><h1 className="b1">Skills for your future</h1><p className="b2">Log in for your special deal and expand your potential. Sale ends today.</p></div>
     <div className="frame2"><div className="b3"><div ><h2 className="b1">A broad selection of courses</h2></div><p  >Choose from 213,000 online video courses with new additions published every month</p></div>
<div>
  
<ul>
  <li onClick={()=>{handlemouseover();handlemouseout1();handlemouseout2();handlemouseout3();handlemouseout4();handlemouseout5();handlemouseout6();}}><a>Python</a></li>
  <li  onClick={()=>{handlemouseover1();handlemouseout();handlemouseout2();handlemouseout3();handlemouseout4();handlemouseout5();handlemouseout6();}}><a >Excel</a></li>
  <li  onClick={()=>{handlemouseover2();handlemouseout1();handlemouseout();handlemouseout3();handlemouseout4();handlemouseout5();handlemouseout6();}}><a >Web Development</a></li>
  <li  onClick={()=>{handlemouseover3();handlemouseout1();handlemouseout();handlemouseout2();handlemouseout4();handlemouseout5();handlemouseout6();}}><a>javascript</a></li>
  <li  onClick={()=>{handlemouseover4();handlemouseout1();handlemouseout();handlemouseout3();handlemouseout2();handlemouseout5();handlemouseout6();}}><a >DataScience</a></li>
  <li  onClick={()=>{handlemouseover5();handlemouseout1();handlemouseout();handlemouseout3();handlemouseout4();handlemouseout2();handlemouseout6();}}><a >AwsCertification</a></li>
  <li  onClick={()=>{handlemouseover6();handlemouseout1();handlemouseout();handlemouseout3();handlemouseout4();handlemouseout5();handlemouseout2();}}><a>Drawing</a></li>
 
  
  
</ul>



</div>
<Contain>{ishovering&&
<div >
  <div class="headshot-banner--content--38t9w"><h2 class="ud-heading-xl headshot-banner--tagline--1lyQ8">Expand your career opportunities with Python</h2><p class="ud-text-md headshot-banner--description--1eU68">Take one of Udemy’s range of Python courses and learn how to code using this incredibly useful language. Its simple syntax and readability makes Python perfect for Flask, Django, data science, and machine learning. You’ll learn how to build everything from games to sites to apps. Choose from a range of courses that will appeal to both beginners and advanced developers alike.</p></div>
  <Carousel cols={3} rows={1} gap={10} loop responsiveLayout='true'>
      <Carousel.Item>
        <img width="50%" src="https://picsum.photos/800/600?random=1" />
      </Carousel.Item>
      <Carousel.Item>
        <img width="50%" src="https://picsum.photos/800/600?random=2" />
      </Carousel.Item>
      <Carousel.Item>
        <img width="50%" src="https://picsum.photos/800/600?random=3" />
      </Carousel.Item>
      <Carousel.Item>
        {/* anything you want to show in the grid */}
      </Carousel.Item>
      {/* ... */}
    </Carousel>
</div>}

{ishovering1&&
<div >
<div class="headshot-banner--content--38t9w"><h2 class="ud-heading-xl headshot-banner--tagline--1lyQ8">Analyze and visualize data with Excel</h2><p class="ud-text-md headshot-banner--description--1eU68">Take a Microsoft Excel course from Udemy, and learn how to use this industry-standard software. Real-world experts will show you the basics like how to organize data into sheets, rows and columns, and advanced techniques like creating complex dynamic formulas. Both small businesses and large companies use Excel to turn their raw data into actionable insights.</p></div>
</div>}
{ishovering2&&
<div >
<div class="headshot-banner--content--38t9w"><h2 class="ud-heading-xl headshot-banner--tagline--1lyQ8">Build websites and applications with Web Development</h2><p class="ud-text-md headshot-banner--description--1eU68">The world of web development is as wide as the internet itself. Much of our social and vocational lives play out on the internet, which prompts new industries aimed at creating, managing, and debugging the websites and applications that we increasingly rely on.</p></div>
</div>}
{ishovering3&&
<div >
<div class="headshot-banner--content--38t9w"><h2 class="ud-heading-xl headshot-banner--tagline--1lyQ8">Grow your software development skills with JavaScript</h2><p class="ud-text-md headshot-banner--description--1eU68">JavaScript is a text-based computer programming language used to make dynamic web pages. A must-learn for aspiring web developers or programmers, JavaScript can be used for features like image carousels, displaying countdowns and timers, and playing media on a webpage. With JavaScript online classes, you can learn to build interactive web applications, choose the best framework, and work with other programming languages like HTML and CSS. </p></div>
</div>}
{ishovering4&&
<div >
<div class="headshot-banner--banner-wrapper--A5R-w"><div class="headshot-banner--content--38t9w"><h2 class="ud-heading-xl headshot-banner--tagline--1lyQ8">Lead data-driven decisions with Data Science</h2><p class="ud-text-md headshot-banner--description--1eU68">Data science application is an in-demand skill in many industries worldwide — including finance, transportation, education, manufacturing, human resources, and banking. Explore data science courses with Python, statistics, machine learning, and more to grow your knowledge. Get data science training if you’re into research, statistics, and analytics.</p></div><a href="/topic/data-science/" class="ud-btn ud-btn-medium ud-btn-secondary ud-heading-sm"><span>Explore Data Science</span></a></div>
</div>}
{ishovering5&&
<div >
<div class="headshot-banner--content--38t9w"><h2 class="ud-heading-xl headshot-banner--tagline--1lyQ8">Become an expert in cloud computing with AWS Certification</h2><p class="ud-text-md headshot-banner--description--1eU68">Prep for your AWS certification with an AWS course on Udemy. Learn the fundamentals of AWS such as working with a serverless platform, the various frameworks, security and more. With these courses, you’ll build the valuable skills you need to implement cloud initiatives — and open up new career opportunities. If you want to become an AWS developer, we’ve got the course for you.</p></div>
</div>}
{ishovering6&&
<div >
<div class="headshot-banner--content--38t9w"><h2 class="ud-heading-xl headshot-banner--tagline--1lyQ8">Expand your creative skillset with Drawing</h2><p class="ud-text-md headshot-banner--description--1eU68">Want to start drawing for fun or take your craft to the next level? Explore our online drawing classes and learn pencil drawing, figure drawing, cartoon drawing, character drawing for cartoons and anime, illustration, sketching, shading and more. Take an overview course on the fundamentals of drawing or zero in on an area you’d like to improve with a specialized course. We’ve got tons of options to get — and keep — you going.</p></div>
</div>}
</Contain>


    </div>
    </div>




    
  );
}

export default Content;
