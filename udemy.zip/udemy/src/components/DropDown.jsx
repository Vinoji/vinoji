
import { useState } from "react";
import './/contents/Dropdown/drop.scss'
import { BsChevronLeft } from "react-icons/bs";
import { BsChevronRight } from "react-icons/bs";
function Card({ selectedValue, onClose }) {
  return (
    <div  id='top'className={`card ${selectedValue}`} style={{position:'absolute',marginTop:'-530px',marginRight:'80px',height:'100%',border:'none',zIndex:200,width:'91.3%'}}>
      <div> <h6><BsChevronLeft onClick={onClose} />  <span style={{paddingLeft:'10px'}}>Menu</span></h6></div>
      <div className="content">
        {selectedValue === "option1" && (
          <div style={{fontSize:'14px',paddingTop:'20px'}}>
<div>
  Web Development
</div>
<div>
 JavaScript
</div>
<div>
 React js
</div>
<div>
  Python
</div>
           
          </div>
        )}
        {selectedValue === "option2" && (
         <div style={{fontSize:'14px',paddingTop:'20px'}}>
         <div>
           Web Development
         </div>
         <div>
          JavaScript
         </div>
         <div>
          React js
         </div>
         <div>
           Python
         </div>
                    
                   </div>
        )}
        {selectedValue === "option3" && (
          <div>
           
            <p>
              Duis aute irure dolor in reprehenderit in voluptate velit esse
              cillum dolore eu fugiat nulla pariatur.
            </p>
          </div>
        )}
      </div>
      
    </div>
  );
}

function ExampleComponent() {
  const [selectedValue, setSelectedValue] = useState(null);
  const [showCard, setShowCard] = useState(false);

  function handleValueChange(newValue) {
    setSelectedValue(newValue);
    setShowCard(true);
  }

  function handleCloseCard() {
    setShowCard(false);
  }

  return (
    <div>
      <div style={{fontSize:'14px',fontWeight:500,lineHeight:'40px'}}>
        <div onClick={() => handleValueChange("option1")}><span >Web Development</span><span><BsChevronRight id='c' size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >Mobile Development</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>


        <div onClick={() => handleValueChange("option2")}><span >Game Development</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >Entrepreneurship</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >Business</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >Digital Marketing</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >Graphic Design</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >IT Certification</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >Personal Transform</span><span><BsChevronRight  id='c'size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
        <div onClick={() => handleValueChange("option2")}><span >Category</span><span><BsChevronRight  id='c' size={15}style={{position:'sticky',left:'175px',marginTop:'5px'}}/></span></div>
       
      </div>

      {showCard && (
        <div className="overlay">
          <Card selectedValue={selectedValue} onClose={handleCloseCard} />
        </div>
      )}
    </div>
  );
}

export default ExampleComponent;
