import React from "react";
import "./company.scss";

function TrustedCompanies() {
  return (
    <div className="trustedCompanies">
      <h2 className="heading">Trusted by over 13,400 great teams</h2>
      <p>Leading companies use the same courses to help employees keep their skills fresh.</p>
      <div className="companiesLogos">
        <ul>
      <li> <img
          alt="booking.com"
          className="booking-com companyLogo"
          src="https://s.udemycdn.com/partner-logos/v4/nasdaq-dark.svg"
        ></img></li> 
     <li>  <img
          alt="volkswagen"
          className="volkswagen companyLogo"
          src="https://s.udemycdn.com/partner-logos/volkswagen-logo.svg"
        ></img></li> 
      <li>  <img
          alt="mercedes-benz"
          className="mercedes-benz companyLogo"
          src="	https://s.udemycdn.com/partner-logos/v4/box-dark.svg"
        ></img></li>
       <li> <img
          alt="adidas"
          className="adidas companyLogo"
          src="	https://s.udemycdn.com/partner-logos/v4/netapp-dark.svg"
        ></img></li>
      <li>  <img
          alt="eventbrite"
          className="eventbrite companyLogo"
          src="https://s.udemycdn.com/partner-logos/eventbrite-logo.svg"
        ></img></li>
        <li><img
          alt="eventbrite"
          className="eventbrite companyLogo"
          src="	https://s.udemycdn.com/partner-logos/v4/tcs-dark.svg"
        ></img></li> 
        </ul>
      </div>
    </div>
  );
}

export default TrustedCompanies;