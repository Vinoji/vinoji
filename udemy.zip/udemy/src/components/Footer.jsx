// import React from "react";
// import "./footer.scss";
// import logo from './/assets/logo-udemy.svg';
// function Footer() {
//   return (
//     <div className="footer">
//       <div className="upperDiv">
//         <div className="linksContainer">
//           <div className="linksDiv linksDiv1">
//             <p>Udemy for Business</p>
//             <p>Teach on Udemy</p>
//             <p>Get the app</p>
//             <p>About us</p>
//             <p>Contact us</p>
//           </div>
//           <div className="linksDiv linksDiv2">
//             <p>Careers</p>
//             <p>Blog</p>
//             <p>Help and Support</p>
//             <p>Affliate</p>
//             <p> </p>
//           </div>
//           <div className="linksDiv linksDiv3">
//             <p>Terms</p>
//             <p>Privacy policy and cookie policy</p>
//             <p>Sitemap</p>
//             <p>Featured courses</p>
//             <p> </p>
//           </div>
//         </div>
//         <div className="linksDiv linksDiv4"></div>
//       </div>
//       <div className="lowerDiv">
//         <img src='	https://www.udemy.com/staticx/udemy/images/v7/logo-udemy-inverted.svg' width={91}height={34.2}></img>
//         <div className="copyrightDiv">
//           <p>© 2023 Udemy, Inc.</p>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Footer;


import React from "react";
import "./footer.scss";

function Footer() {
  return (
    <div className="footer">
      <div className="footer__text">
        <div className="footer__left">
          <p>
            <a href="https://www.udemy.com/udemy-business/?locale=en_US&mx_pg=home-page&path=%2F&ref=footer">
              Udemy Business
            </a>
          </p>
          <p>
            <a href="https://www.udemy.com/teaching/?ref=teach_footer">
              Teach on Udemy
            </a>
          </p>
          <p>
            <a href="https://www.udemy.com/mobile/">Get the app</a>
          </p>
          <p>
            <a href="https://about.udemy.com/?locale=en-us">About us</a>
          </p>
          <p>
            <a href="https://about.udemy.com/company?locale=en-us#offices">
              Contact us
            </a>
          </p>
        </div>
        <div className="footer__center">
          <p>
            <a href="https://about.udemy.com/careers?locale=en-us">Careers</a>
          </p>
          <p>
            <a href="https://blog.udemy.com/?ref=footer">Blog</a>
          </p>
          <p>
            <a href="https://www.udemy.com/support/">Help and Support</a>
          </p>
          <p>
            <a href="https://www.udemy.com/affiliate/">Affiliate</a>
          </p>
        </div>
        <div className="footer__footer__right">
          <p>
            <a href="https://www.udemy.com/terms/">Terms</a>
          </p>
          <p>
            <a href="https://www.udemy.com/terms/privacy/">Privacy policy</a>
          </p>
          <p>
            <a href="https://www.udemy.com/sitemap/">Sitemap</a>
          </p>
        </div>
      </div>
      <img
        src="https://www.udemy.com/staticx/udemy/images/v7/logo-udemy-inverted.svg"
        alt="logo"
        className="footer__image"
      />
      <p className="footer__smallText">© 2023 Udemy, Inc.</p>
    </div>
  );
}

export default Footer;