import React, { useState } from 'react';
import './pcard.scss';

function HoverPopup(props) {
  const [showPopup, setShowPopup] = useState(false);

  function handleMouseEnter() {
    setShowPopup(true);
  }

  function handleMouseLeave() {
    setShowPopup(false);
  }

  return (
    <div className="hover-popup-container" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
      {props.children}
      {showPopup && <div className="hover-popup">{props.popupContent}</div>}
    </div>
  );
}

export default HoverPopup;
