import React from "react";
import "./categoryCard.scss";

function CategoryCard(props) {
  return (
  <div>  <div className="categoryCard">
      <img
        src={props.imgSrc}
        alt={props.title + " img"}
        className="categoryImg"
      ></img></div>
      <h3 className="categoryTitl titl">{props.title}</h3>
      </div>
  );
}

export default CategoryCard;