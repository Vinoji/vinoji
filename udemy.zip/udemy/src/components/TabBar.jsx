import React from 'react'
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import './tabbar.scss'
import Carousel1 from 'better-react-carousel'
import VideoCard from './Vidio';

import py from './/assets/py1.jpg';
import py2 from './/assets/py3.png';
import Button from 'react-bootstrap/Button';
import d11 from './/assets/gio3.png';
import d12 from './/assets/gio2.png';
import d13 from './/assets/av.jpg';
import d9 from './/assets/gio.png';
import d10 from './/assets/gio1.png';
const TabBar = () => {
  return (
    <div className='tap'>
    <Tabs
    defaultActiveKey="profile"
    id="uncontrolled-tab-example "
    className="mb-3 "
    
    
  >
    <Tab eventKey="home" title="Python">
    <div className='contain'><div >
      
      <div className="headshot-banner--content--38t9w" style={{textAlign:'left',marginLeft:'20px'}}><h2 className='bannet1'>Expand your career opportunities with Python</h2><p className="text1">Take one of Udemy’s range of Python courses and learn how to code using this incredibly useful language. Its simple syntax and readability makes Python perfect for Flask, Django, data science, and machine learning. You’ll learn how to build everything from games to sites to apps. Choose from a range of courses that will appeal to...</p><Button  style={{borderRadius:'0px',fontWeight:'700',marginTop:'20px'}}variant="outline-dark">Explore Python</Button></div>
      
      </div><></><div style={{marginTop:'20px'}}>
      <Carousel1 cols={5} rows={1} gap={10} loop responsiveLayout='true' style={{marginTop:'20px'}}>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d10}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d9}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d11}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d12}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            {/* ... */}
          </Carousel1>
      
      </div></div>
    </Tab>
    <Tab eventKey="profile" title="Excel">
    <div className='contain'><div >
      
      <div className="headshot-banner--content--38t9w" style={{textAlign:'left',marginLeft:'20px'}}><h2 className='bannet1'>Analyze and visualize data with Excel</h2><p className="text1">Take a Microsoft Excel course from Udemy, and learn how to use this industry-standard software. Real-world experts will show you the basics like how to organize data into sheets, rows and columns, and advanced techniques like creating complex dynamic formulas. Both small businesses and large companies use Excel to..</p><Button  style={{borderRadius:'0px',fontWeight:'700',marginTop:'20px'}}variant="outline-dark">Explore Excel</Button></div>
      
      </div><></><div style={{marginTop:'20px'}}>
      <Carousel1 cols={5} rows={1} gap={10} loop responsiveLayout='true' style={{marginTop:'20px'}}>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d10}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d9}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d11}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d12}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            {/* ... */}
          </Carousel1>
      
      </div></div>
    </Tab>

    <Tab eventKey="2" title="DataScience">
    <div className='contain'><div >
      
      <div className="headshot-banner--content--38t9w" style={{textAlign:'left',marginLeft:'20px'}}><h2 className='bannet1'>Build websites and applications with Web Development</h2><p className="text1">The world of web development is as wide as the internet itself. Much of our social and vocational lives play out on the internet, which prompts new industries aimed at creating, managing, and debugging the websites and applications that we increasingly rely on...</p><Button  style={{borderRadius:'0px',fontWeight:'700',marginTop:'20px'}}variant="outline-dark">Explore Web Development</Button></div>
      
      </div><></><div style={{marginTop:'20px'}}>
      <Carousel1 cols={5} rows={1} gap={10} loop responsiveLayout='true' style={{marginTop:'20px'}}>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d10}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d9}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d11}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d12}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            {/* ... */}
          </Carousel1>
      
      </div></div>
    </Tab>

    <Tab eventKey="profile1" title="JavaScript">
    <div className='contain'><div >
      
      <div className="headshot-banner--content--38t9w" style={{textAlign:'left',marginLeft:'20px'}}><h2 className='bannet1'>Analyze and visualize data with Excel</h2><p className="text1">Take a Microsoft Excel course from Udemy, and learn how to use this industry-standard software. Real-world experts will show you the basics like how to organize data into sheets, rows and columns, and advanced techniques like creating complex dynamic formulas. Both small businesses and large companies use Excel to..</p><Button  clasName='button'style={{borderRadius:'0px',fontWeight:'700',marginTop:'20px'}}variant="outline-dark">Explore Excel</Button></div>
      
      </div><></><div style={{marginTop:'20px'}}>
      <Carousel1 cols={5} rows={1} gap={10} loop responsiveLayout='true' style={{marginTop:'20px'}}>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d10}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d9}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d11}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={d12}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            <Carousel1.Item>
            <VideoCard
              courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
              imgSrc={py}
              instructor={"Kyle Pew, Office Newb LLC"}
              rating={4.6}
              noOfStudents={"(166,042)"}
              price={"₹8,640"}
            />
            </Carousel1.Item>
            {/* ... */}
          </Carousel1>
      
      </div></div>
    </Tab>
    
  </Tabs>
  </div>
  )
}

export default TabBar