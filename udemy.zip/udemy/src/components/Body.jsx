import React from 'react'
import Carousel from 'react-bootstrap/Carousel';
import { useState } from 'react';
import logo from './/assets/logo.jpg';
import logo2 from './/assets/logo2.jpg';
import d1 from './/assets/d1.jpg';
import d2 from './/assets/d2.jpg';
import d3 from './/assets/d3.jpg';
import d4 from './/assets/d4.jpg';
import d5 from './/assets/d5.jpg';
import d6 from './/assets/d6.jpg';
import d7 from './/assets/d7.jpg';
import d8 from './/assets/d8.jpg';
import d9 from './/assets/gio.png';
import d10 from './/assets/gio1.png';
import d11 from './/assets/gio3.png';
import d12 from './/assets/gio2.png';
import d13 from './/assets/av.jpg';

import './Style.scss'
import { Row } from 'react-bootstrap';
import CategoryCard from './CategoryCard';
import Button from 'react-bootstrap/Button';
import Company from './Company';
import Carousel1 from 'better-react-carousel'
import VideoCard from './Vidio';
import Card2 from './Card2';
import { ImQuotesLeft, ImYoutube } from "react-icons/im";
import py from './/assets/py1.jpg';
import py2 from './/assets/py3.png';
import UdemyForBusiness from './Business';
import BecomeInstructor from './Instructor';
import Footer from './Footer';
import Dropdown from './DropDown'
import { BsPlayCircleFill } from 'react-icons/bs';
import { fontWeight } from '@mui/system';
import TabBar from './TabBar';

const Body = () => {
  const userNames = ['Python','Excel','Web Development','Javascript','DataScience','Aws Certification','Drawing']
  const [Active,Setactive]=useState('')
 
  const handclick=(value)=>{
    Setactive(value)
  }
  return (

<div>
  
                                                {/* // Body */}
    <div className='car'>
    <Carousel>
    <Carousel.Item interval={10000}>
      <img
        className="d-block w-100"
        src={logo}
        
      /><div ><div  id='ba'className='banner1'><Row><h1 className="b1">Learning that gets you</h1><p className="b2">Skills for your present (and your future). Get started with us.</p></Row></div></div> 
      <div id='ba1' style={{padding:'20px'}}><Row><h1 className="b1">Learning that gets you</h1><p className="b2">Skills for your present (and your future). Get started with us.</p></Row></div>
        
    </Carousel.Item>
  
    <Carousel.Item interval={500}>
      <img
        className="d-block w-100"
        src={logo2}
        alt="Second slide"
      /><div ><div id='ba4' className='banner2'><Row><h1 className="b1">Unlock the power of your people</h1><p className="b2">Udemy Business is trusted by 12.5K+ companies around the world. <a href="url">Find out what we can do for yours.</a></p></Row></div></div>

<div id='ba3' style={{padding:'20px'}}><Row><h1 className="b1">Unlock the power of your people</h1><p className="b3">Udemy Business is trusted by 12.5K+ companies around the world. <a href="url">Find out what we can do for yours.</a></p></Row></div>
      
       
      
    </Carousel.Item>
    
  </Carousel>

  <div className='container1'>
    <div style={{marginLeft:'10px'}} ><div ><h2 className="v1">A broad selection of courses</h2></div>
    <p  className='b3' >Choose from 213,000 online video courses with new additions published every month</p></div>
    </div>

                                  {/* Tabs */}
     
    <TabBar/>


                                            {/* learners*/}
                                   
<div className='contain2'>
  <h1 className='bannet1' style={{marginLeft:'20px'}}>How learners like you are achieving their goals</h1>
  <Carousel1 cols={3} rows={1} gap={20} loop responsiveLayout='true' style={{marginTop:'20px'}}>
  <Carousel1.Item>
<Card2>
  <ImQuotesLeft/>
<span style={{marginBottom:'16px'}}>I am proud to say that after a few months of taking this course...<span style={{ fontWeight: 'bold' }}>freshen up on my product manager skills and land a job at Facebook! </span> This content was exactly what the CCP exam covered.</span>
<div style={{display:'flex',}}> <img
       width={32}
       height={32}
        src={d13}
        style={{borderRadius:'50%'}}
        
      />
      <span  className='titl' style={{marginLeft:'10px',paddingBottom:'20px'}}>Ab A</span>
      
      </div>
      <div >
  <hr></hr>
  <div style={{display:'flex'}}><div><BsPlayCircleFill  size={30} style={{color:'#5727D3'}}/></div>
  <span  className='titl'style={{color:'#401B9C'}}>[NEW] Ultimate AWS Certified Cloud Practitioner - 2022</span></div>
      </div>
</Card2></Carousel1.Item>
<Carousel1.Item>
<Card2>
  <ImQuotesLeft/>
<span style={{marginBottom:'16px'}}>I am proud to say that after a few months of taking this course...<span style={{ fontWeight: 'bold' }}>I passed my exam and am now an AWS Certified Cloud Practitioner!</span> This content was exactly what the CCP exam covered.</span>

<div style={{display:'flex',}}> <img
       width={32}
       height={32}
        src={d13}
        style={{borderRadius:'50%'}}
        
      />
      <span className='titl' style={{marginLeft:'10px',paddingBottom:'20px'}}>Ab A</span>
      
      </div>
      <div >
  <hr></hr>
  <div style={{display:'flex'}}><div ><BsPlayCircleFill  size={30} style={{color:'#5727D3'}}/></div>
  <span  className='titl'style={{color:'#401B9C'}}>[NEW] Ultimate AWS Certified Cloud Practitioner - 2022</span></div>
      </div>
</Card2></Carousel1.Item>
<Carousel1.Item>
<Card2>
  <ImQuotesLeft/>
<span style={{marginBottom:'16px'}}>One of the best courses on management and leadership I have come across so far. The advice is practical, and examples highly relatable.<span style={{ fontWeight: 'bold' }}>Would help anyone become a better manager.</span> </span>

<div style={{display:'flex',}}> <img
       width={32}
       height={32}
        src={d13}
        style={{borderRadius:'50%'}}
        
      />
      <span className='titl' style={{ marginLeft:'10px',paddingBottom:'20px'}}>AbiL A</span>
      
      </div>
      <div >
  <hr></hr>
  <div style={{display:'flex'}}><div><BsPlayCircleFill size={30} style={{color:'#5727D3'}}/></div>
  <span  className='titl'style={{color:'#401B9C'}}>[NEW] Ultimate AWS Certified Cloud Practitioner - 2022</span></div>
      </div>
</Card2></Carousel1.Item>
</Carousel1>
</div>
                                             {/* Student View  */}
    
    <div className='studentview' style={{}}>
      <h1 className='bannet1' style={{marginTop:'60px',marginLeft:'20px'}}>Students are viewing</h1> 
    <Carousel1 cols={5} rows={1} gap={20} loop responsiveLayout='true' style={{marginTop:'20px',marginRight:'10px'}}>
      <Carousel1.Item>
      <VideoCard
        courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
        imgSrc={py2}
        instructor={"Kyle Pew, Office Newb LLC"}
        rating={4.6}
        noOfStudents={"(166,042)"}
        price={"₹8,640"}
      />
      </Carousel1.Item>
      <Carousel1.Item>
      <VideoCard
        courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
        imgSrc={py2}
        instructor={"Kyle Pew, Office Newb LLC"}
        rating={4.6}
        noOfStudents={"(166,042)"}
        price={"₹8,640"}
      />
      </Carousel1.Item>
      <Carousel1.Item>
      <VideoCard
        courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
        imgSrc={py2}
        instructor={"Kyle Pew, Office Newb LLC"}
        rating={4.6}
        noOfStudents={"(166,042)"}
        price={"₹8,640"}
      />
      </Carousel1.Item>
      <Carousel1.Item>
      <VideoCard
        courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
        imgSrc={py2}
        instructor={"Kyle Pew, Office Newb LLC"}
        rating={4.6}
        noOfStudents={"(166,042)"}
        price={"₹8,640"}
      />
      </Carousel1.Item>
      <Carousel1.Item>
      <VideoCard
        courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
        imgSrc={py2}
        instructor={"Kyle Pew, Office Newb LLC"}
        rating={4.6}
        noOfStudents={"(166,042)"}
        price={"₹8,640"}
      />
      </Carousel1.Item>
      <Carousel1.Item>
      <VideoCard
        courseTitle={"Microsoft Excel - Excel from Beginner to Advanced"}
        imgSrc={py2}
        instructor={"Kyle Pew, Office Newb LLC"}
        rating={4.6}
        noOfStudents={"(166,042)"}
        price={"₹8,640"}
      />
      </Carousel1.Item>
      {/* ... */}
    </Carousel1>
</div>


                                                                     
                             {/* Category */ } 


<div className='category1' style={{padding:'24px'}}>
<div className="topCategories">
      <h3 className="bannet1 ">Top Categories</h3>
      <div className="categories">
        <CategoryCard
          imgSrc={
           d1
          }
          title={"Design"}
        />
        <CategoryCard
          imgSrc={
           d2
          }
          title={"Development"}
        />
        <CategoryCard
          imgSrc={
           d3
          }
          title={"Marketing"}
        />
        <CategoryCard
          imgSrc={
            d4
          }
          title={"IT and Software"}
        />
        <CategoryCard
          imgSrc={
            d5
          }
          title={"Personal Development"}
        />
        <CategoryCard
          imgSrc={
            d6
          }
          title={"Business"}
        />
        <CategoryCard
          imgSrc={
            d7
          }
          title={"Photography"}
        />
        <CategoryCard
          imgSrc={
           d8
          }
          title={"Music"}
        />
      </div>
    </div> 
</div>                  
                                   {/* Featured Topic */}

<div className='feature' style={{padding:'64px 24px',backgroundColor:'#F7F9FA',textAlign:'left',}}>
<section ><h3 className="bannet1">Featured topics by category</h3><div style={{display:'flex',justifyContent:'space-between',flexWrap:'wrap',marginRight:'30px',width:'100%',marginTop:'30px',marginBottom:'50px'}}><div style={{width:'280px'}}>
  <h4 className='categoryTitle'>Development</h4>
  <div style={{fontWeight:'700'}}> <a href="url" style={{color:'#5727D3'}}>Python</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    36,354,994 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url" style={{color:'#5727D3'}}>Web Development</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    11,415,615 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>Machine Learning</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    7,070,015 students
    </div>


    
  
</div>

<div style={{width:'280px'}}>
  <h4 className='categoryTitle'>Business</h4>
  <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>Financial Analysis</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    1,195,282 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>SQL</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    5,977,561 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>PMP</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    1,733,398 students
    </div>


    
  
</div>


<div style={{width:'280px'}}>
  <h4 className='categoryTitle'>IT and Software</h4>
  <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>AWS Certification</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    6,078,244 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>Ethical Hacking</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    10,931,066 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>Cyber Security</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    3,998,037 students
    </div>

    


    
  
</div>


<div style={{width:'280px'}}>
  <h4 className='categoryTitle'>Design</h4>
  <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>Photoshop</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    10,909,736 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>Graphic Design</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    3,381,052 students
    </div>

    <div style={{fontWeight:'700'}}><a href="url"style={{color:'#5727D3'}}>Drawing</a></div>
    <div style={{fontSize:'14px',paddingBottom:'10px',color:'#7d7d7d',fontWeight:500}}>
    2,410,849 students
    </div>

    



    
  
</div>

  </div><div style={{paddingTop:'20px'}}><Button  style={{borderRadius:'0px',fontWeight:'700'}}variant="outline-dark">Explore more topics</Button></div></section></div>

                               { /* Company */}

<Company/>
                             {/* Business */}


 <UdemyForBusiness/>


                             {/* Instructor   */}
<BecomeInstructor/>
<Footer/> 




  </div></div>
  
  )
}

export default Body