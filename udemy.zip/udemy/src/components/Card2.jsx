import React from "react";
import'./card.scss';
import {AiOutlineStar} from 'react-icons/ai'
// import StarBorderIcon from "@material-ui/icons/StarBorder";
import {FaStarHalfAlt} from 'react-icons/fa'

function Card(props) {
  return (
    <div className="videoCard1">
     {props.children}
    </div>
  );
}

export default Card;